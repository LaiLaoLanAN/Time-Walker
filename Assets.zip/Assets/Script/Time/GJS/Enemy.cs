using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    public int maxHealth = 3;
    private int currentHealth;

    public float knockbackForce = 8f;
    public float stunTime = 0.3f;

    private Rigidbody2D rb;
    private Animator anim;
    private MonsterController enemyController;
    private HitEffectController hitEffectController;
    private bool isStunned = false;
    private bool isInvincible = false;

    [Header("��ʯ����")]
    public GameObject gemPrefab;
    public float gemInitialUpSpeed = 6f;
    public float gemGroundOffset = 0.3f;      // ���Yƫ�ƣ�����ڹ���λ�ã�
    public float gemSpawnOffsetY = 0.5f;      // ����Yƫ�ƣ�����ڹ���λ�ã�
    public float gemSpawnDelay = 0.4f;        // �� �������������ӳٶ�����ɱ�ʯ

    private Coroutine invincibleCoroutine;

    void Start()
    {
        currentHealth = maxHealth;
        rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
        enemyController = GetComponent<MonsterController>();
        hitEffectController = GetComponent<HitEffectController>();
    }

    public void TakeDamage(int damage, Transform attacker)
    {
        if (currentHealth <= 0 || isInvincible) return;

        currentHealth -= damage;

        if (hitEffectController != null)
            hitEffectController.TriggerHitEffect();

        Vector2 knockbackDirection = (transform.position - attacker.position).normalized;
        rb.velocity = new Vector2(knockbackDirection.x * knockbackForce, rb.velocity.y);

        StartCoroutine(StunCoroutine());

        if (currentHealth <= 0)
        {
            Debug.Log(2);
            Die();
        }
    }

    IEnumerator StunCoroutine()
    {
        isStunned = true;
        if (enemyController != null)
            enemyController.enabled = false;

        yield return new WaitForSeconds(stunTime);

        isStunned = false;
        if (enemyController != null)
            enemyController.enabled = true;
    }

    public void Die()
    {
        StopAllCoroutines();
        if (enemyController != null)
            enemyController.enabled = false;

        // ����������Ч�����ָ����ʣ�
        if (hitEffectController != null)
            hitEffectController.TriggerHitEffect(1, false);

        // ������ײ��
        foreach (var col in GetComponents<Collider2D>())
            col.enabled = false;

        rb.velocity = Vector2.zero;
        rb.isKinematic = true;

        // �� �ӳ����ɱ�ʯ
        if (gemPrefab != null)
        {
            StartCoroutine(SpawnGemAfterDelay(gemSpawnDelay));
        }

        this.enabled = false;
        Destroy(gameObject, 0.93f);  // ������ʱ����ڱ�ʯ�ӳ� + ��Чʱ��
    }

    private IEnumerator SpawnGemAfterDelay(float delay)
    {
        yield return new WaitForSeconds(delay);

        // �����ڹ���λ�� + Yƫ��
        Vector3 spawnPos = new Vector3(transform.position.x, transform.position.y + gemSpawnOffsetY, transform.position.z);
        GameObject gemObj = Instantiate(gemPrefab, spawnPos, Quaternion.identity);
        Gem gem = gemObj.GetComponent<Gem>();
        if (gem != null)
        {
            float groundY = transform.position.y + gemGroundOffset;
            gem.Initialize(groundY, gemInitialUpSpeed);
        }
        else
        {
            Debug.LogWarning("��ʯԤ����ȱ�� Gem �����");
        }
    }

    public void TriggerHitEffect()
    {
        if (hitEffectController != null)
            hitEffectController.TriggerHitEffect(0);
    }

    void Update() { }
}