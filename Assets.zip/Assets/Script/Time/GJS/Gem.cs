using UnityEngine;

public class Gem : MonoBehaviour
{
    // ---- ԭ�в��� ----
    [Header("��������")]
    public float attractoffsetY = 0.2f;
    public float attractDistance = 1f;
    public float maxSpeed = 5f;
    public float minSpeed = 0.5f;

    [Header("��������")]
    public float wobbleSpeed = 2f;
    public float amplitude = 0.12f;

    [Header("��������ֵ")]
    public int value = 33;

    [Header("��������")]
    public float gravity = 15f;
    public float groundY;

    // ---- ˽���ֶ� ----
    private Transform playerTransform;
    private MCscript playerScript;
    private bool isCollected = false;
    private float landTime;
    private float floatEaseInDuration = 0.3f;
    private bool isInitialized = false;
    private Vector3 basePosition;
    private Vector3 initialPosition;

    private enum State { Thrown, Idle, Attracting }
    private State currentState = State.Thrown;

    private float verticalSpeed;

    private float smoothDistRatio = 1f;
    private float velocityRef = 0f;

    private int skipLandCheckFrames = 0;
    private float throwStartTime;
    private bool hasPeaked = false;

    // ---- ��ʼ������ ----
    public void Initialize(float groundY, float initialUpSpeed)
    {
        this.groundY = groundY;
        verticalSpeed = initialUpSpeed;
        currentState = State.Thrown;
        isCollected = false;
        skipLandCheckFrames = 3;
        throwStartTime = Time.time;
        hasPeaked = false;

        basePosition = transform.position;
        initialPosition = transform.position;

        // Debug.Log($"��Initialize������ groundY = {groundY}, initialUpSpeed = {initialUpSpeed}");

        Collider2D col = GetComponent<Collider2D>();
        if (col != null && !col.isTrigger)
            col.isTrigger = true;
        isInitialized = true;
    }

    private void Start()
    {
        GameObject player = GameObject.FindGameObjectWithTag("Player");
        if (player != null)
        {
            playerTransform = player.transform;
            playerScript = player.GetComponent<MCscript>();
        }
        else
        {
            Debug.LogError("δ�ҵ� Tag Ϊ 'Player' ����Ϸ����");
        }

        // �� ���δͨ�� Initialize ��ʼ��������Ϊֱ�ӷ���ģʽ������״̬��
        if (!isInitialized)
        {
            groundY = transform.position.y;
            basePosition = transform.position;
            currentState = State.Idle;
            landTime = Time.time; // ���ø���

            Collider2D col = GetComponent<Collider2D>();
            if (col != null && !col.isTrigger)
                col.isTrigger = true;
        }
    }

    private void Update()
    {
        if (isCollected || playerTransform == null) return;

        switch (currentState)
        {
            case State.Thrown:
                UpdateThrown();
                break;
            case State.Idle:
                UpdateIdle();
                break;
            case State.Attracting:
                UpdateAttracting();
                break;
        }

        // ---- �������� ----
        float offsetY = 0f;
        if (currentState == State.Idle || currentState == State.Attracting)
        {
            Vector3 targetPos = playerTransform.position + new Vector3(0, attractoffsetY, 0);
            float distToTarget = Vector2.Distance(basePosition, targetPos);
            float rawRatio = Mathf.Clamp01(distToTarget / attractDistance);
            smoothDistRatio = Mathf.SmoothDamp(smoothDistRatio, rawRatio, ref velocityRef, 0.15f);

            float floatEase = 1f;
            if (landTime > 0)
            {
                float t = (Time.time - landTime) / floatEaseInDuration;
                floatEase = Mathf.Clamp01(t);
            }
            offsetY = amplitude * smoothDistRatio * floatEase * Mathf.Sin(Time.time * wobbleSpeed);
        }

        transform.position = new Vector3(basePosition.x, basePosition.y + offsetY, basePosition.z);
    }

    private void UpdateThrown()
    {
        // ���Գ��ٶ�
        if (skipLandCheckFrames == 3)
        {
            // Debug.Log($"�����ס����ٶ� = {verticalSpeed}, ����Y = {basePosition.y}, groundY = {groundY}");
        }

        // ������ؼ��
        if (skipLandCheckFrames > 0)
        {
            skipLandCheckFrames--;
            verticalSpeed -= gravity * Time.deltaTime;
            basePosition.y += verticalSpeed * Time.deltaTime;
            return;
        }

        // ���������ٶ�
        verticalSpeed -= gravity * Time.deltaTime;
        basePosition.y += verticalSpeed * Time.deltaTime;

        // ����Ƿ�ﵽ��ߵ㣨�ٶ�����ת����
        if (verticalSpeed <= 0 && !hasPeaked)
        {
            hasPeaked = true;
        }

        // ��ؼ��
        if (verticalSpeed <= 0 && basePosition.y <= groundY)
        {
            basePosition.y = groundY;
            verticalSpeed = 0f;
            currentState = State.Idle;
            landTime = Time.time;
            Debug.Log("Gem landed.");
            return;
        }

        // �� ��ǰ��������������׶Σ�hasPeakedΪtrue���Ҿ���һ���ӳ٣���֤���׶�����
        if (hasPeaked && Time.time - throwStartTime > 0.2f)
        {
            float distToPlayer = Vector2.Distance(basePosition, playerTransform.position);
            if (distToPlayer <= attractDistance)
            {
                verticalSpeed = 0f;
                currentState = State.Attracting;
                // Debug.Log("Gem attracted during falling.");
            }
        }
    }

    // ---- ����״̬ ----
    private void UpdateIdle()
    {
        if (basePosition.y > groundY)
        {
            verticalSpeed -= gravity * Time.deltaTime;
            basePosition.y += verticalSpeed * Time.deltaTime;
            if (basePosition.y <= groundY)
            {
                basePosition.y = groundY;
                verticalSpeed = 0f;
                landTime = Time.time;
            }
        }
        else
        {
            basePosition.y = groundY;
            verticalSpeed = 0f;
            if (landTime < 0) landTime = Time.time;
        }

        Vector3 targetPos = playerTransform.position + new Vector3(0, attractoffsetY, 0);
        float distance = Vector2.Distance(basePosition, targetPos);
        if (distance <= attractDistance)
        {
            currentState = State.Attracting;
            verticalSpeed = 0f;
            // Debug.Log("Gem attracted from Idle.");
        }
    }

    // ---- ����״̬ ----
    private void UpdateAttracting()
    {
        Vector3 targetPos = playerTransform.position + new Vector3(0, attractoffsetY, 0);
        float distance = Vector2.Distance(basePosition, targetPos);

        if (distance > 0.01f)
        {
            Vector2 direction = (targetPos - basePosition).normalized;
            float t = Mathf.Clamp01(distance / attractDistance);
            float smoothT = Mathf.SmoothStep(0f, 1f, t);
            float currentSpeed = Mathf.Lerp(maxSpeed, minSpeed, smoothT);
            basePosition += (Vector3)(direction * currentSpeed * Time.deltaTime);
        }

        if (distance > attractDistance)
        {
            currentState = State.Idle;
            verticalSpeed = 0f;
            // Debug.Log("Player left, returning to Idle.");
        }

        float realDistance = Vector2.Distance(transform.position, targetPos);
        if (realDistance < 0.05f)
        {
            Collect();
        }
    }

    private void Collect()
    {
        if (isCollected) return;
        isCollected = true;

        if (playerScript != null)
            playerScript.CollectGem(value);
        else
            Debug.LogWarning("��ҽű������ڣ��޷�ʰȡ��");

        StartCoroutine(FadeOutAndDestroy());
    }

    private System.Collections.IEnumerator FadeOutAndDestroy()
    {
        SpriteRenderer sr = GetComponent<SpriteRenderer>();
        if (sr == null)
        {
            Destroy(gameObject);
            yield break;
        }

        float duration = 0.07f;
        float elapsed = 0f;
        Color startColor = sr.color;

        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float alpha = Mathf.Lerp(1f, 0f, elapsed / duration);
            sr.color = new Color(startColor.r, startColor.g, startColor.b, alpha);
            yield return null;
        }

        sr.color = new Color(startColor.r, startColor.g, startColor.b, 0f);
        Destroy(gameObject);
    }
}